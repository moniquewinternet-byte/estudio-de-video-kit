# Estúdio de Vídeo — como instalar

Este é o agente de edição e crescimento de vídeo pra afiliado.

## 1. Onde colocar o agente
Descompacte este .zip e coloque a pasta `estudio-de-video` dentro de
`.claude/skills/` do seu projeto no Claude Code. Tem que ficar assim:
`.claude/skills/estudio-de-video/SKILL.md`

Depois é só conversar com ele, por exemplo: "edita esse vídeo pra Reels".

## 2. O que o agente usa (instale uma vez, pelo Kit)
O agente conversa, mas ele usa estas ferramentas. Instale uma vez cada:
- Ambiente: Node, FFmpeg, yt-dlp e Python (no Claude Code, com winget).
- ffmpeg-skill (edição) e HyperFrames (overlays de preço e CTA).
- faster-whisper, pra legenda em português: `pip install faster-whisper`.
- ElevenLabs (voz), via uv: `winget install astral-sh.uv`, depois peça pro
  Claude conectar a ElevenLabs e cole a sua chave quando ele pedir.
- Postiz (postar): `npm install -g postiz`, depois `postiz auth:login`.

A página do Kit tem o passo a passo de cada um, com botão de copiar.
